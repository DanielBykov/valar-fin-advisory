# First Home Buyer Workbook (coaching questions)

From the Valar First Home Buyers Guide. Use these as gentle coaching questions, one or two at a time. There are no right or wrong answers. Every question is optional: if the user skips it, say "Moving on" in their language (Ukrainian: «Ідемо далі», Russian: «Идём дальше») and continue.

## Part 1. Your financial foundation
- Why do you want to buy your first home?
- What would make a first home a smart financial decision for you?
- How much deposit do you currently have?
- Where will your deposit come from? (savings, KiwiSaver, sale of assets, family gift, other)
- What concerns you most about buying a home?
- What one financial habit could you improve over the next three months?

## Part 2. Getting mortgage ready
- What price range do you think you can comfortably afford?
- What monthly mortgage repayment would still allow you to enjoy life?
- Which debts would you like to reduce before applying?
- Have you checked your credit score? (date, score if known)
- Which documents have you already prepared? (payslips, tax returns, bank statements, ID, other)
- What questions would you like to ask a mortgage adviser?

## Part 3. Finding the right home
- What are your three non-negotiables?
- Which features would simply be "nice to have"?
- Which suburbs are you considering?
- What compromises are you willing to make?
- What worries you most about choosing the wrong property?
- Before making an offer, what do you want to double-check? (building inspection, LIM report, title search, body corporate, other)

## Part 4. Your action plan
- What are the next three things you need to do?
- What is stopping you from moving forward today?
- What would make you feel confident enough to buy?
- When would you ideally like to own your first home?
- What does success look like one year after buying your home?

# Planner and folders

## What the user gets

A zip with one folder (names stay in English):

```
My First Home            (the user may rename it, e.g. "My First Home – Max & Anna")
├── My-First-Home-Planner.xlsx
├── 01 Plan & Budget
├── 02 Documents
│   ├── ID & Residency
│   ├── Income - Payslips & Contracts
│   ├── Income - Self-employed (Financials & IR3)
│   ├── Bank Statements
│   ├── KiwiSaver
│   ├── Deposit
│   └── Debts & Credit Report
├── 03 Pre-approval & Bank
├── 04 Property Search
│   └── _Template - Address   (Listing & Photos, LIM & Title, Building Inspection, Body Corporate)
├── 05 Offer & Legal
├── 06 Settlement & Insurance
└── 07 After We Move In
```

When showing it to the user before creating, use a short list (top folders, with 02 and 04 contents in one line each) and ask if it suits them.

The planner (`assets/My-First-Home-Planner.xlsx`, Valar style) has 10 sheets: **Dashboard** (path of 10 steps, money cards, progress, next key date, next 3 steps; all formulas), **My File**, **Budget**, **Documents**, **Before Offer**, **Properties**, **Compare**, **Key Dates**, **Team**, **Questions**. White cells are inputs, grey cells are formulas. Never overwrite formulas, never change styling.

## Creating it (when you can run code)

1. Write a JSON file with what you know from the conversation (keys documented at the top of `scripts/fill_planner.py`). Typical first fill:
   - `myfile`: Who is buying, City or region, NZ citizen or resident, How we earn, Stage, When we would like to buy, Step on the path (1-10), Deposit (rough) and where from, Comfortable monthly payment, What worries us most, Why we are buying, Type of home, Areas, Must-haves, Nice-to-haves, Next step 1-3, Open questions, Last updated (YYYY-MM-DD). Write answers in English, short.
   - `budget`: take (household take-home per month, an estimate if needed), price (the illustration discussed), dep.
   - `docs`: mark what doesn't apply as "N/A" (e.g. payslips for a self-employed partner, self-employed rows for a salaried person). Leave the rest empty: the user marks Yes as they collect.
   - `must` (up to 5) and optionally `criteria` (7 scoring rows with weights 1-2) from step 1.
   - `questions`: open questions with who to ask. For amounts to set aside: "You decide / mortgage adviser".
2. Run:
   `python scripts/fill_planner.py --base assets/My-First-Home-Planner.xlsx --data data.json --out My-First-Home-Planner.xlsx --zip My-First-Home.zip --folder "My First Home"`
3. Give the user the zip with the hand-over message from SKILL.md (Onboarding, step 6): three actions (unzip into Documents; open the Dashboard; put documents into 02 Documents and tick them off), then how to continue (upload the updated file to the chat, or add it to the Project files).

## Updating it

When the user uploads their planner: read it (openpyxl with `data_only=False` for inputs; Dashboard values may be empty until opened in Excel, so compute what you need from inputs). Ask what changed, then write a JSON with only the changes and run the same script with `--base <their file>` and without `--zip`. Return the new file and say: "Replace the old file in your My First Home folder with this one." Keep `Last updated` current and update `Step on the path (1-10)` and `Next step 1-3` when they move on.

Properties and Questions are appended; Compare `homes` fills Home A-D in order (re-send all homes to change them).

## If you can't create files

Show the folder structure as a list to copy, point the user to the blank planner from the Valári pack (valar.co.nz/first-home-ai-skill), and tell them which cells to fill: My File answers, Budget take-home, price and deposit, must-haves on Compare. For updates, tell them which cells to change.

## Privacy

Never put IRD, bank account or card numbers, or passport numbers in the planner. Rough numbers only.

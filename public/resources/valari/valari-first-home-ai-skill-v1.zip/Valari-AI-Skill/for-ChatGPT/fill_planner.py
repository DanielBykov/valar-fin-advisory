"""Fill or update the Valar My First Home Planner, and optionally build the folders zip.

Usage:
  python fill_planner.py --base assets/My-First-Home-Planner.xlsx --data data.json --out My-First-Home-Planner.xlsx [--zip My-First-Home.zip] [--folder "My First Home"]
  (to update a client's planner, pass their uploaded file as --base)

data.json keys (all optional; only what you pass is written):
  myfile:    {"Who is buying": "...", "Step on the path (1-10)": 2, "Last updated": "2026-10-17", ...}  (labels as in sheet My File)
  budget:    {"take": 10500, "price": 845000, "dep": 100000, "rate": 0.05, "srate": 0.07, "term": 30,
              "law": 3000, "insp": 650, "lim": 500, "val": 1100, "move": 1500, "buf": 5000}
  docs:      {"Payslips, last 2-3 months": ["Yes", "N/A"], "Bank statements, 3 months, all accounts": ["Yes"]}
             (two values = Me, Partner; one value = Shared; use Yes / No / N/A / null)
  checks:    {"Insurance quote: the home can be insured": "Yes"}   (Before Offer, column Done)
  must:      ["North Shore", "2+ bedrooms", ...]                    (up to 5, Compare must-haves)
  criteria:  [["Location and commute", 2], ...]                     (up to 7, Compare score rows: name, weight)
  homes:     [{"address": "...", "price": 850000, "body_corp": 0, "repairs": 0, "must": ["Yes", ...], "scores": [4, 3, ...], "notes": ["stop factors", "liked", "questions", "next step"]}]  (up to 4)
  properties:[["Address", "Suburb", "Price / method", "2026-10-20", "House", 3, "Liked", "Concerns", "LIM", "Inspection", "Status"]]
             (appended after existing rows; Status: Watching, Viewed, Shortlisted, Offer made, Not for us)
  dates:     {"Pre-approval expires": "2026-12-15"}                 (Key Dates, by event label)
  done_dates:["Pre-approval expires"]                              (mark Done = Yes)
  team:      [["Mortgage adviser", "Name", "Company", "Phone", "Email", "Notes"]]  (fills the first empty row of that role)
  questions: [["Question", "Who to ask"]]                           (appended after existing rows)
"""
import argparse, json, os, shutil, tempfile, datetime as dt
from openpyxl import load_workbook

FOLDERS = [
    '01 Plan & Budget',
    '02 Documents/ID & Residency', '02 Documents/Income - Payslips & Contracts', '02 Documents/Income - Self-employed (Financials & IR3)',
    '02 Documents/Bank Statements', '02 Documents/KiwiSaver', '02 Documents/Deposit', '02 Documents/Debts & Credit Report',
    '03 Pre-approval & Bank',
    '04 Property Search/_Template - Address/Listing & Photos', '04 Property Search/_Template - Address/LIM & Title',
    '04 Property Search/_Template - Address/Building Inspection', '04 Property Search/_Template - Address/Body Corporate (townhouse or apartment)',
    '05 Offer & Legal', '06 Settlement & Insurance', '07 After We Move In']

BUDGET_LABELS = {
    'take': 'Monthly take-home income', 'price': 'Home price', 'dep': 'Deposit', 'rate': 'Interest rate', 'srate': 'Stress-test rate',
    'term': 'Loan term', 'law': 'Solicitor', 'insp': 'Building inspection', 'lim': 'LIM report', 'val': 'Valuation', 'move': 'Moving', 'buf': 'Buffer'}


def as_date(v):
    if isinstance(v, str) and len(v) == 10 and v[4] == '-':
        try:
            return dt.date.fromisoformat(v)
        except ValueError:
            return v
    return v


def rows_by_label(ws, col=2, start=7):
    out = {}
    for r in range(start, ws.max_row + 1):
        v = ws.cell(row=r, column=col).value
        if isinstance(v, str) and v.strip():
            out.setdefault(v.strip(), r)
    return out


def find_row(labels, text, exact=False):
    if text in labels:
        return labels[text]
    if not exact:
        for k, r in labels.items():
            if k.lower().startswith(text.lower()):
                return r
    return None


def first_empty(ws, col, start, stop):
    for r in range(start, stop + 1):
        if ws.cell(row=r, column=col).value in (None, ''):
            return r
    return None


def section_rows(ws, title):
    """Rows of a Compare section: from the band row with this title to the next band/blank."""
    lab = rows_by_label(ws)
    start = next(r for k, r in lab.items() if k.upper().startswith(title.upper()))
    rows = []
    r = start + 1
    while ws.cell(row=r, column=2).value not in (None, ''):
        v = str(ws.cell(row=r, column=2).value)
        if v.isupper():
            break
        rows.append(r); r += 1
    return rows


def fill(base, data, out):
    wb = load_workbook(base, rich_text=True)
    # My File
    ws = wb['My File']; lab = rows_by_label(ws)
    for k, v in data.get('myfile', {}).items():
        r = find_row(lab, k, exact=True)
        if r: ws.cell(row=r, column=3).value = as_date(v)
    # Budget
    ws = wb['Budget']; lab = rows_by_label(ws)
    for k, v in data.get('budget', {}).items():
        r = find_row(lab, BUDGET_LABELS.get(k, k))
        if r: ws.cell(row=r, column=3).value = v
    # Documents
    ws = wb['Documents']; lab = rows_by_label(ws)
    for k, vals in data.get('docs', {}).items():
        r = find_row(lab, k)
        if not r: continue
        cols = (3, 4) if len(vals) == 2 else (5,)
        for c, v in zip(cols, vals):
            if v is not None: ws.cell(row=r, column=c).value = v
    # Before Offer
    ws = wb['Before Offer']; lab = rows_by_label(ws)
    for k, v in data.get('checks', {}).items():
        r = find_row(lab, k)
        if r: ws.cell(row=r, column=3).value = v
    # Compare
    ws = wb['Compare']
    must_rows = section_rows(ws, 'MUST-HAVES')[:5]
    for r, m in zip(must_rows, data.get('must', [])):
        ws.cell(row=r, column=2).value = m
    score_rows = section_rows(ws, 'SCORES')
    score_rows = [r for r in score_rows if not str(ws.cell(row=r, column=2).value).startswith('Weighted')][:7]
    for r, (name, w) in zip(score_rows, data.get('criteria', [])):
        ws.cell(row=r, column=2).value = name; ws.cell(row=r, column=3).value = w
    cost_rows = section_rows(ws, 'MONTHLY COST')
    note_rows = section_rows(ws, 'STOP FACTORS')
    addr_row = rows_by_label(ws).get('Address', 7)
    for i, h in enumerate(data.get('homes', [])[:4]):
        c = 4 + i
        if 'address' in h: ws.cell(row=addr_row, column=c).value = h['address']
        for r, v in zip(must_rows, h.get('must', [])): ws.cell(row=r, column=c).value = v
        if 'price' in h: ws.cell(row=cost_rows[0], column=c).value = h['price']
        if 'body_corp' in h: ws.cell(row=cost_rows[4], column=c).value = h['body_corp']
        if 'repairs' in h: ws.cell(row=cost_rows[7], column=c).value = h['repairs']
        for r, v in zip(score_rows, h.get('scores', [])): ws.cell(row=r, column=c).value = v
        for r, v in zip(note_rows, h.get('notes', [])): ws.cell(row=r, column=c).value = v
    # Properties
    ws = wb['Properties']
    for row in data.get('properties', []):
        r = first_empty(ws, 2, 7, ws.max_row)
        if not r: break
        for j, v in enumerate(row): ws.cell(row=r, column=2 + j).value = as_date(v)
    # Key Dates
    ws = wb['Key Dates']; lab = rows_by_label(ws)
    for k, v in data.get('dates', {}).items():
        r = find_row(lab, k)
        if r is None:  # an event not in the list: use the spare 'Auction or deadline' row if free
            spare = find_row(lab, 'Auction or deadline')
            if spare and ws.cell(row=spare, column=3).value in (None, ''):
                r = spare; ws.cell(row=r, column=2).value = k
        if r: ws.cell(row=r, column=3).value = as_date(v)
    for k in data.get('done_dates', []):
        r = find_row(lab, k)
        if r: ws.cell(row=r, column=6).value = 'Yes'
    # Team
    ws = wb['Team']
    for row in data.get('team', []):
        for r in range(7, ws.max_row + 1):
            if ws.cell(row=r, column=2).value == row[0] and ws.cell(row=r, column=3).value in (None, ''):
                for j, v in enumerate(row[1:]): ws.cell(row=r, column=3 + j).value = v
                break
    # Questions
    ws = wb['Questions']
    for q in data.get('questions', []):
        r = first_empty(ws, 2, 7, ws.max_row)
        if not r: break
        for j, v in enumerate(q): ws.cell(row=r, column=2 + j).value = v
    wb.calculation.fullCalcOnLoad = True
    wb.save(out)


def make_zip(planner, zip_path, folder):
    tmp = tempfile.mkdtemp()
    root = os.path.join(tmp, folder)
    for f in FOLDERS:
        os.makedirs(os.path.join(root, f), exist_ok=True)
    shutil.copy(planner, os.path.join(root, 'My-First-Home-Planner.xlsx'))
    base = zip_path[:-4] if zip_path.endswith('.zip') else zip_path
    shutil.make_archive(base, 'zip', tmp, folder)
    shutil.rmtree(tmp)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--base', required=True); ap.add_argument('--data', required=True); ap.add_argument('--out', required=True)
    ap.add_argument('--zip'); ap.add_argument('--folder', default='My First Home')
    a = ap.parse_args()
    fill(a.base, json.load(open(a.data, encoding='utf-8')), a.out)
    if a.zip:
        make_zip(a.out, a.zip, a.folder)
    print('saved', a.out, a.zip or '')

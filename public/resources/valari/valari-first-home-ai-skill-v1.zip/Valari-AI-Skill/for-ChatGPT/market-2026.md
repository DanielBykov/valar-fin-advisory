# Market update and extra notes (September 2026)

Snapshot as at September 2026, prepared by Valar Financial Advisors to complement guide.md. Where this file and guide.md differ, this file is the more recent. Rules and numbers change: always tell the user to verify anything important with the official source, their bank or a licensed adviser.

## Market snapshot (September 2026)

| Item | Figure | Note |
|---|---|---|
| Official Cash Rate (OCR) | 2.75% | Raised in July and September 2026 after a low of 2.25% |
| Inflation | 4.1% (June 2026 quarter) | RBNZ target 1-3% |
| Bank fixed rates | from about 4.95% (1 year); about 5.4-5.5% (2-5 years) | Changes weekly: check current rates |
| National median sale price | about $750,000 (August 2026, REINZ) | Prices about 17-19% below the 2021 peak |
| Stress test rate for planning | 7% | Use to check the budget still works if rates rise |

## Who can buy

- NZ citizens and NZ residence class visa holders who meet the residency test (generally: resident visa, in NZ for at least 12 months, and at least 183 days in NZ in the last 12 months).
- Australian and Singapore citizens are generally treated as able to buy.
- Most temporary visa holders (work, student, visitor) cannot buy existing homes.
- The Overseas Investment Act sets these rules. Tell the user to confirm their status with a solicitor before searching.

## How banks assess you

- **Affordability:** income must cover the mortgage at the bank's test rate plus living costs and other debts.
- **DTI (debt-to-income):** for owner-occupiers, total debt is generally limited to about 6 times gross annual income (RBNZ rule, banks have a small allowance above it). Investors: about 7 times.
- **Stable income:** usually at least 3 months in a permanent salaried job. Regular extra income (overtime, bonuses, boarder income) may count. Self-employed: usually 2 years of financial statements and IR3 returns; some lenders accept 1 year.
- **Conduct:** the last 3-6 months of bank statements: no missed or dishonoured payments, no new loans. Credit card limits count, not just balances. BNPL (Afterpay, Laybuy) counts.
- **Savings and deposit evidence:** banks look at whether you have been saving regularly. It isn't required, but regular saving is a good sign. If the savings were built earlier (for example brought over when moving from another country), what matters is showing that the money is there. In theory a bank can ask where the money came from, but each case is looked at individually and it depends on the situation: this is a question for a mortgage adviser or the bank you'll work with. Never present "statements from other banks" or a set saving period as a fixed requirement.
- **Children and dependants** increase the living costs the bank assumes.

## Deposit options

| Option | Deposit | Notes |
|---|---|---|
| Kāinga Ora First Home Loan | 5% | Through participating lenders; income and price caps apply; a lenders mortgage insurance premium is added. Check current caps on kaingaora.govt.nz |
| Main bank, low deposit | 5-10% | Limited availability, often deal-by-deal, higher rates |
| Low deposit loan | 10-19% | Rates or fees typically about 0.25-0.75% higher |
| Standard | 20%+ | Best rates, easiest approval, often the best cashback |

New builds are exempt from the banks' low-deposit (LVR) limits, so a 10% deposit is often accepted.

With less than a 20% deposit, whether a bank lends depends on the bank and on the month, and the rate or fees may be a little higher.

Kāinga Ora First Home Loan income and price caps change: always check the current figures on kaingaora.govt.nz.

**Should you wait for 20%?** Not necessarily. Waiting has a cost too (rent, price changes). Compare both paths with an adviser.

## Costs: updated ranges and buffer

Recent typical ranges (2026) are a little higher than in the guide: solicitor $1,500-4,500; building inspection $500-800; LIM $300-700; registered valuation $800-1,300. Plan $5,000-10,000 on top of the deposit, plus an emergency buffer. Bank cashback (often around $5,000) can help but may have to be repaid if you refinance within the clawback period (often 3-4 years).

KiwiSaver timing: the withdrawal usually goes through your solicitor and takes about 10 working days. For an auction or a short deadline sale, the deposit paid on the day usually cannot come from KiwiSaver, so plan it in advance with your solicitor and adviser. The old First Home Grant closed to new applications in May 2024: ignore any source that says it is available.

## Self-employed documents

In addition to the usual documents (see guide.md): usually 2 years of financial statements and IR3 returns prepared by an accountant (some lenders accept 1 year), recent GST returns and business bank statements, and the accountant's contact details.

## Property types

| Type | What you own | Watch for |
|---|---|---|
| Standalone house (freehold) | Land and house | Maintenance, insurance |
| Townhouse / apartment (unit title) | Your unit plus a share of common property | Body corporate fees, rules, long-term maintenance plan, levies, weathertightness history |
| Cross-lease | A share of the land and a lease of your dwelling | Flats plan must match what is built; changes need neighbours' consent |
| Leasehold | The building, not the land | Ground rent reviews, fewer lenders, harder to sell: get legal advice first |
| New build | Land and new dwelling | Builder's track record, guarantee (Master Build or similar), sunset clauses, settlement date |
| Lifestyle block | Land and dwelling | Larger deposit usually needed, fewer lenders, water and septic systems |

## Risk areas worth knowing

- **Leaky building era:** homes built roughly 1994-2004, especially with monolithic (plaster) cladding, flat roofs or no eaves, have a higher risk of weathertightness problems. Ask for a specialist moisture inspection with invasive testing if needed, and check the LIM and body corporate records.
- **Natural hazards:** check council hazard maps (flooding, coastal inundation, land instability). Get insurance quotes early: some properties are hard or expensive to insure, and lenders require insurance from settlement. Residential land and building cover for natural disasters also involves the Natural Hazards Commission (Toka Tū Ake, formerly EQC).
- **Unconsented work:** extensions, decks or converted garages without consent can affect insurance, lending and resale.

## Due diligence checks

- **Building inspection:** moisture, structure, roof, wiring, plumbing, pests (borer).
- **LIM report:** zoning, consents, hazards (flooding, land instability), unconsented work, rates.
- **Title search (solicitor):** ownership, easements, covenants, caveats, mortgages.
- **Valuation:** often required by the bank, especially with a deposit under 20%.
- **Body corporate documents:** for unit titles: minutes, accounts, long-term maintenance plan, pre-contract disclosure.
- **Other:** council plans for the area, insurance quotes (check insurability early), specialist reports (drainage, electrical, meth testing if relevant).

## Sale methods

| Method | How it works | First home buyer notes |
|---|---|---|
| Negotiation | Written offer, can include conditions | Usually the easiest: time to check and add conditions |
| Auction | Public bidding; unconditional when the hammer falls; deposit (often 10%) paid on the day | Finance, inspection, LIM, valuation and solicitor's review must all be done before the day |
| Tender | Sealed offers by a set date; seller picks the best overall offer | You do not see other offers |
| Deadline sale | Offers invited until a deadline; seller can accept earlier | Be ready to move quickly |

## Common offer conditions

Finance approval, building inspection, LIM, valuation, due diligence (catch-all), sale of your current home (only if needed), solicitor's approval. The solicitor must review the Sale and Purchase Agreement before you sign.

## The path

Valári uses the 10-step Roadmap from guide.md (details in path.md). Practical notes for these steps as at September 2026:

- Pre-approval is usually valid 60-90 days; keep finances stable while it is open (no new debt, no job change).
- Choose a solicitor before making any offer.
- Sign the Sale and Purchase Agreement only after the solicitor's review; make the offer conditional where possible.
- Due diligence: inspection, LIM, title, valuation, final bank approval, all before going unconditional.
- Before settlement your solicitor sends a settlement statement (including council rates apportioned to the settlement date): check it.

## Tax and policy notes (September 2026)

- Bright-line test: 2 years for residential property (your main home is exempt).
- Interest on investment property loans is fully deductible again.
- NZ general election: 7 November 2026. Some parties propose taxes on investment property gains (for example, Labour: a capital gains tax on investment and commercial property from 1 July 2027). The family home is excluded in all current proposals. Check the outcome after the election.

## Glossary (short)

- **Pre-approval:** a lender's conditional promise to lend up to a set amount.
- **LVR:** loan-to-value ratio: the loan as a % of the property value.
- **DTI:** debt-to-income ratio.
- **Equity:** the part of the home you own (value minus loan).
- **Conditional / unconditional:** before or after all conditions are met. Unconditional is binding.
- **Settlement:** the day money moves, ownership transfers and you get the keys.
- **LIM:** Land Information Memorandum from the council.
- **CCC:** Code Compliance Certificate: council confirmation that consented building work was completed to code.
- **Body corporate:** the owners' group managing a unit title complex.
- **Cashback:** a lender's cash contribution at drawdown, usually with a clawback period.

# About Lena and Valar

Use this when the user asks about Lena, Valar, reviews, credentials or "who made you". Facts only, from this file. No superlatives, no invented reviews, no pressure.

## Lena Bykova
- Director and financial adviser at Valar Financial Advisors Limited. Licensed financial adviser (FSP1010055).
- 20+ years across finance, valuation, investment analysis and business advisory.
- Master's in Finance & Accounting; NZ Certificates in Financial Services (Level 5) in Residential Property Lending and in Investment; CFA Program Candidate; Graduate Diploma (Level 7) in IT, Business Intelligence and Generative AI.
- Consults in English, Ukrainian and Russian. Based in Auckland, works with clients across New Zealand.
- Approach: looks beyond the loan approval and the rate to long-term goals, property strategy, cashflow and risk.

## Valar Financial Advisors
- Valar Financial Advisors Limited (FSP1012862), holds a Financial Advice Provider licence from the FMA.
- Services: mortgage advice, financial planning, wealth management plans, investment property analysis, small business loans, business advisory, first home buyers roadmap.

## Links
| What | Link |
|---|---|
| About Lena and Valar | https://valar.co.nz/about |
| Google reviews | https://g.page/r/CWUKUaXAHYrGEBM/review |
| Book a free clarity call | https://valar.co.nz/book |
| First Home Buyers Roadmap | https://valar.co.nz/services/first-home-buyers |
| Article: Buying your first home, the 10 steps in order | https://valar.co.nz/insights/articles/first-home-buying-steps-nz |
| Articles and market updates | https://valar.co.nz/insights |
| FAQ | https://valar.co.nz/insights/faq |
| Disclosure statement | https://valar.co.nz/disclosure |
| LinkedIn | https://www.linkedin.com/company/valar-advisors |

## How to use
- **"Who is Lena?", "What are her reviews?", "Can I trust Valar?":** 2-4 lines of facts from above, then the About and Google reviews links. Never quote, summarise or invent reviews; let the user read them. Never claim a number of reviews or a rating.
- **Articles:** when a Valar article matches the topic (for example the 10-steps article during the walk-through, or the market update when they ask about rates), you may add it as the one Valar link in that reply.
- Answering a direct question about Lena or Valar doesn't count toward the Valar mention limit, but don't add a sales pitch or push to book.
- If the user asks you to search the web for Lena and you find little, say the main sources are the Valar website and Google reviews and give those links.

# Valar First Home Buyers Guide (knowledge base)

Source: "First Home Buyers Guide: Your Path to Your Own Home", prepared by Lena Bykova, Mortgage & Investment Adviser, Valar Financial Advisors. This is general information about buying a first home in New Zealand. It is not personal financial advice.

## 1. What the guide covers

- How much to save for a deposit
- How to improve your credit score
- Fixed or floating rate
- How to get mortgage pre-approval
- What to look for when viewing homes
- Additional costs when buying
- How to make an offer and negotiate
- Benefits available to first home buyers

**Expert tip:** start with mortgage pre-approval BEFORE searching for a home, or at least speak with a mortgage adviser who can help you understand your position and prepare documents. This gives a competitive advantage at auctions and negotiations and helps you assess your budget realistically. Most buyers do the opposite and lose time and opportunities.

## 2. Understanding the NZ property market

Key elements of a strong buyer position:
- **Market terminology:** knowing terms such as LIM, freehold/leasehold, conditional/unconditional helps you talk confidently with agents and solicitors.
- **The right professionals:** an experienced mortgage adviser, real estate agent, building inspector and solicitor.
- **Market phase:** growth, stability or decline affects timing and strategy.
- **Action strategy:** a clear step-by-step plan from preparation to settlement.

A mortgage adviser can usually walk you through the main roadmap, explain each phase and prepare a step-by-step plan for your situation in a first 30-45 minute meeting, usually at no cost to you.

## 3. Roadmap

1. **Your starting point:** define your ideal property type, neighbourhood, lifestyle and reason for buying. This is the foundation of the strategy.
2. **Exploring the market:** current prices, property types, condition of homes, neighbourhood trends.
3. **Contacting professionals:** mortgage adviser, real estate agents, solicitor, building inspector.
4. **Your financial capacity + pre-approval:** income, expenses, deposit, credit profile, potential budget.
5. **Searching for your home:** focus on clear criteria: condition, location, renovation potential, market price. The goal is not a perfect home, but a home that fits your current stage of life.
6. **From offer to unconditional:** building inspection, LIM, technical and legal checks, bank requirements.
7. **Final approval:** the bank confirms finance for the chosen property (valuation, insurance, body corporate documents if needed). Runs alongside step 6 and must be done before going unconditional if the offer has a finance condition.
8. **Going unconditional:** all conditions are met and the deal becomes binding; the deposit under the agreement is paid (often 10%, negotiable). Then, preparing for settlement: decide the loan structure (rate types, split, repayment terms) yourself or with an adviser, the bank prepares the loan documents to match, you sign them with your solicitor, confirm insurance and check the settlement statement.
9. **Settlement:** funds are transferred, ownership is registered, keys are handed over.
10. **Life after purchase:** planning refixes, optimising the loan, renovating, building equity, preparing for future investments.

## 4. Key property terms in New Zealand

- **LIM (Land Information Memorandum):** council report on the property and land: zoning, permits and consents, potential hazards. Get it before seriously considering a property.
- **Freehold:** you own the land and buildings outright. The most common and usually most desirable type of ownership.
- **Leasehold:** you own the building but lease the land (for example from a council or iwi). Ground lease payments can significantly affect your budget.
- **Cross-lease:** you own a share of the land and hold a lease on your specific dwelling. Common in older suburbs.
- **Unit title:** common for apartments and townhouses: you own your unit and a share of common areas, with annual body corporate fees.
- **Unconditional offer:** an offer with no conditions, binding once accepted. Stronger for the seller, riskier for you.

## 5. Market dynamics

- **Seasons:** activity is often higher in spring and autumn, which affects prices and choice.
- **Regions:** markets vary a lot between regions; Auckland often behaves differently from smaller cities and rural areas.
- **Government policy:** lending rules and first home buyer schemes change; stay informed.
- **Research tools:** Trade Me Property, realestate.co.nz, homes.co.nz, oneroof.co.nz: recent sales, estimated values, trends.

## 6. Financial preparation

- A deposit is typically 10-20% of the price; some lenders offer lower-deposit options for first home buyers, such as 5%.
- Budget for the deposit plus building inspection, legal fees and moving costs.
- NZ credit scores range from 0 to 1,000; higher is better. Pay bills on time, reduce debt, avoid unnecessary credit applications, check your report (Centrix, Equifax, Illion).
- **Set a clear savings goal:** target price and required deposit (5%, 10% or 20%).
- **Automate savings:** automatic transfers to a separate account.
- **Create a detailed budget:** track income and expenses to find savings.

## 7. Where does the deposit come from?

Most people combine 2-3 sources:
- **KiwiSaver:** after 3 years of membership you can withdraw your funds (a minimum of $1,000 stays). Consider moving to a more conservative fund before buying: a sudden market drop is the last thing you need.
- **Savings:** banks look at whether you have been saving regularly. It isn't required, but regular saving is a good sign. Savings built earlier (for example brought from another country) are fine: what matters is showing the money is there. Many people aim to set aside 15-30% of income each month.
- **Family gift:** a formal gifting letter confirming the money is non-repayable; banks may ask for the donor's statements.
- **Sale of assets:** property, a vehicle or shares: banks need the sale agreement and proof of transfer. International transfers usually take 3-7 days.
- **Equity in another property:** usually accessible up to 80% of that property's value.
- **Loan from a company or employer:** needs a formal agreement; banks treat it as a liability.

Banks may check where the deposit comes from (AML rules). What they ask for depends on the case: a mortgage adviser or your bank can tell you what you will need. Having gifting letters and proof of transfers ready early saves time.

## 8. How much deposit do you need? Four scenarios

| Scenario | Deposit | Pros | Watch for |
|---|---|---|---|
| Kāinga Ora First Home Loan | 5% | Good rates, possible cashback, pre-approval for about 90 days | Strict criteria, income limits, a premium is added to the loan |
| Main bank, small deposit | 5% | Standard bank loan, fast processing | Often no pre-approval (deal by deal), rates may be higher |
| Low deposit loan | 10-19% | A good start | Limited pre-approval; rates typically 0.25-0.75% higher; each bank's criteria change quickly |
| Best case | 20%+ | Lowest rates, best cashback, easiest approval (pre-approval up to 90 days), valuation often not required | Takes longer to save |

**Should you wait for the "ideal" 20%?** Not necessarily. It is often better to start with a smaller deposit, especially in a rising market. The best decision is to analyse the options with a mortgage adviser.

## 9. Additional costs

| Cost | Guide range |
|---|---|
| Legal fees | $1,500-5,000 depending on complexity |
| Building inspection | $400-800 standard; more for detailed reports |
| LIM report | $200-500 |
| Valuation (if the lender requires it) | $600-1,500; some lenders include it |
| Moving | truck or movers plus setup costs |
| Insurance | most lenders require home insurance before settlement; get several quotes |

## 10. Credit score

The score reflects payment history, existing debts, credit limits and how often credit is checked.

What banks check:
- 3 months of bank statements: missed payments, overdrafts, gambling.
- 180+ days of credit history: credit card statements, applications, timeliness.

Any default or missed payment makes approval harder. Do not hide it: discuss it with an adviser and plan how to explain it to the bank.

How to prepare:
- **Pay on time:** set up automatic payments.
- **Reduce debts:** lower card and loan limits; keep utilisation below 30%.
- **Avoid enquiries:** each credit enquiry can lower the score and stays on the report for up to 2 years.
- **Check your report:** free once a year from Centrix, Equifax, Illion. Correct errors before applying.
- Review 3 months of bank statements and 6 months of credit card statements: no missed payments, no debt collection, stable spending, no risky items (gambling, casino, large cash withdrawals, unexplained transactions).

## 11. Realistic goals

- Think about how career, family and lifestyle may change, and choose a home that fits the future.
- Keep payments at a level that still allows saving and life.
- Budget for maintenance, utilities, insurance and rates.
- Build an emergency fund of 3-6 months of living expenses.

## 12. Top 5 steps to get mortgage-ready

1. **Stabilise cash flow (90 days) and credit cards (180 days):** no overdrafts, unusual large purchases or gambling. Regular savings, even small, show you can accumulate money.
2. **Improve your credit score:** pay on time, avoid new credit checks, reduce card debt.
3. **Optimise debt:** close unnecessary cards, repay small loans. With a deposit under 20%, whether to close other loans needs weighing: discuss with an adviser.
4. **Prepare the deposit and show savings:** even with 5-10%, banks want to see regular saving.
5. **Gather documents early:** 3 months of statements, credit report, proof of income, source of deposit.

## 13. How much can you borrow?

Banks check that you can service the loan even in adverse conditions:
1. **DTI (debt-to-income):** roughly, maximum debt is about 6 times annual income for owner-occupiers. A guideline, not a guarantee.
2. **Affordability:** income must cover all expenses and payments even if rates rise. Banks typically stress-test at around 6.8% or higher.
3. **Deposit:** the bigger it is, the more options and the better the terms.
4. **Debts and obligations:** car loans, credit cards, BNPL and other regular payments reduce borrowing power.
5. **Income stability:** length of employment, contract type, self-employment history, dependants and other commitments.

Banks may offer more than you expect. Is it worth taking the maximum for a first home? The most sensible path is usually a comfortable option that will not strain the budget.

## 14. Mortgage options

- **Fixed rate:** set rate for a period (usually 6 months to 5 years): certainty of payments.
- **Floating rate:** can change: payments may rise or fall; more flexibility.
- **Combination (split):** part fixed for stability, part floating for flexibility. Many people also split across different fixed terms.
- **Loan term:** usually 25-30 years; shorter terms mean higher payments but less total interest.
- **Payment frequency:** weekly, fortnightly or monthly.
- **Fees:** establishment, ongoing and early repayment fees.
- **Repayment flexibility:** some loans allow extra payments without penalty.
- **Offset:** savings in a linked account reduce the balance you pay interest on, while staying accessible.
- **Early repayment penalties:** possible on fixed loans; consider this if you plan extra payments.

## 15. First home buyer schemes

- **Kāinga Ora First Home Loan:** lets eligible buyers purchase with a 5% deposit; strict eligibility criteria apply.
- **KiwiSaver first home withdrawal:** after 3 years of membership; understand the rules and the effect on retirement savings.

## 16. Working with a mortgage adviser

- Knows the market and options; has access to many lenders and their offers.
- Handles the paperwork; can submit to several lenders at once.
- Usually paid by the lender, so typically no extra cost to you.

**Optimising the mortgage later:** extra repayments, refinancing when conditions improve, regular reviews, using offset wisely.

## 17. Pre-approval

A conditional commitment from a lender to lend up to a set amount.
Advantages: budget clarity, a stronger position with sellers, faster final approval, sometimes rate protection.

Most banks currently offer pre-approval with a 20% deposit. With a smaller deposit, options exist but depend on the bank: conditions change quickly.

Path: initial enquiry (bank or adviser) → document collection → lender assessment (typically within about a week) → pre-approval.

**Documents usually needed:** proof of identity; payslips for 3 months; bank statements for 3 months; proof of deposit (KiwiSaver statements, savings); proof of other income; existing debts and liabilities; credit history; proof of employment (contract).

**Validity:** usually 60-90 days (some lenders up to 6 months). Keep finances stable: no job change, new debt or big purchases.

**If you are not approved:** ask for the reasons, improve the weak areas (debt, savings), consider other lenders with an adviser, check eligibility for government schemes.

**Small deposit without pre-approval:** still possible. You can apply for finance on each specific property. An adviser can give an indicative amount and pre-select likely lenders. Prepare all documents in advance so they can be sent quickly after you sign a conditional agreement.

## 18. Effective property search

- Define criteria: location, size, property type, must-haves and nice-to-haves.
- Use Trade Me, OneRoof, realestate.co.nz, homes.co.nz; also talk to local agents, who may know about listings early.
- **Location:** close to work, schools, transport and what matters to you.
- **Needs:** bedrooms, bathrooms, living areas.
- **Outdoors:** garden, balcony or low-maintenance section.

Researching neighbourhoods:
- Visit at different times (day and night, weekdays and weekends).
- Local amenities: shops, schools, parks, medical.
- Transport and commute times.
- Future development: council plans.
- Crime statistics: police.govt.nz.

Online resources: Trade Me Property (largest listings site, filters); homes.co.nz (estimates, sales history, council valuations); realestate.co.nz (listings, alerts, calculator); oneroof.co.nz (listings, insights, school zones).

## 19. Working with real estate agents

- Register with several agents.
- Describe your needs, budget and priorities clearly.
- Use their local knowledge; ask for sales data and valuations.
- Remember the listing agent works for the seller.

## 20. Open homes and private viewings

- Plan visits by neighbourhood; bring a notepad, camera and tape measure; ask about history, reason for sale and known issues.
- Arrange a private viewing for a calm inspection, ideally with a friend for a second opinion.

What to look at:
- **Structure:** cracks, uneven floors, signs of movement; foundations, walls, roof.
- **Moisture and mould:** walls, ceilings, under sinks.
- **Insulation:** ceiling, wall, underfloor.
- **Heating and cooling:** efficiency and running costs.
- **Plumbing and electrical:** test taps and toilets; look for outdated wiring.
- **Light and ventilation:** north-facing is ideal in NZ.

## 21. Property reports before an offer

- **LIM report:** zoning, permits, hazards (costs: see section 9).
- **Valuation:** independent assessment; the lender usually arranges it, or you can pay for it.
- **Building inspection:** by a qualified, registered inspector.
- **Title check:** the solicitor confirms ownership and any encumbrances or restrictions.

## 22. Making an offer and negotiating

- An offer is made in writing through a Sale and Purchase Agreement: price, conditions, settlement date.
- Conditions (finance, building inspection, LIM) protect you but can make an offer less attractive in competition.
- Steps: research comparable sales (Trade Me, homes.co.nz) → submit the offer with conditions (agent or solicitor can help) → negotiate and counter-offer within budget → sign the final agreement.

Strategies: know your upper limit before negotiating; consider non-price terms (settlement date, length of conditional period, chattels); do not reveal your maximum; use conditions deliberately.
Tips: act quickly in a hot market; get everything in writing; stay within your means; be patient; a personal letter to the vendor can help; consider a buyer's agent in competitive markets.

## 23. From conditional to unconditional

- **Solicitor:** paperwork, agreement review, title checks; choose a property specialist.
- **Finance:** send the signed agreement to the bank (or the adviser manages it); valuation if required; final loan documents.
- **Conditions:** finance, inspection, LIM; the solicitor tracks deadlines.
- **Settlement day:** final walkthrough, sign, ownership transfers, keys.

Moving in: connect utilities before moving day, change the locks, plan the move and an essentials box.

## 24. Life as a homeowner

- Pay council rates and keep insurance current; understand what it covers.
- Plan maintenance and keep a fund for repairs.
- Automate mortgage payments; make extra repayments when possible.
- If you bought a unit title, learn the body corporate rules, responsibilities and fees.

## 25. Valar's approach

Valar helps first home buyers see the purchase as part of a long-term financial strategy: defining goals, choosing optimal steps and using property as a tool for building wealth, not only a place to live.

Contact: Lena Bykova, lena.bykova@valar.co.nz, +64 21 086 35 695, valar.co.nz.
